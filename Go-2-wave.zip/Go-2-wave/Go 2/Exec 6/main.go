package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

type Domino struct {
	A, B int
}

func (d Domino) Flip() Domino {
	return Domino{d.B, d.A}
}

func buildChain(chain []Domino, used []bool, pieces []Domino) ([]Domino, bool) {
	if len(chain) == len(pieces) {
		if chain[0].A == chain[len(chain)-1].B {
			return chain, true
		}
		return nil, false
	}

	last := chain[len(chain)-1].B

	for i, piece := range pieces {
		if used[i] {
			continue
		}
		if piece.A == last {
			used[i] = true
			result, ok := buildChain(append(chain, piece), used, pieces)
			if ok {
				return result, true
			}
			used[i] = false
		} else if piece.B == last {
			used[i] = true
			result, ok := buildChain(append(chain, piece.Flip()), used, pieces)
			if ok {
				return result, true
			}
			used[i] = false
		}
	}
	return nil, false
}

func findDominoChain(pieces []Domino) ([]Domino, bool) {
	for i, piece := range pieces {
		used := make([]bool, len(pieces))
		used[i] = true

		chain, ok := buildChain([]Domino{piece}, used, pieces)
		if ok {
			return chain, true
		}
		chain, ok = buildChain([]Domino{piece.Flip()}, used, pieces)
		if ok {
			return chain, true
		}
	}
	return nil, false
}

func main() {
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Quantas peças você deseja informar? ")
	input, _ := reader.ReadString('\n')
	qtde, _ := strconv.Atoi(strings.TrimSpace(input))

	var pieces []Domino

	for i := 0; i < qtde; i++ {
		fmt.Printf("Informe a peça %d no formato A|B (ex: 2|3): ", i+1)
		line, _ := reader.ReadString('\n')
		line = strings.TrimSpace(line)
		partes := strings.Split(line, "|")
		if len(partes) != 2 {
			fmt.Println("Formato inválido! Tente novamente.")
			i--
			continue
		}
		a, err1 := strconv.Atoi(strings.TrimSpace(partes[0]))
		b, err2 := strconv.Atoi(strings.TrimSpace(partes[1]))
		if err1 != nil || err2 != nil {
			fmt.Println("Números inválidos! Tente novamente.")
			i--
			continue
		}
		pieces = append(pieces, Domino{a, b})
	}

	chain, ok := findDominoChain(pieces)
	if ok {
		fmt.Println("\nCadeia válida encontrada:")
		for _, d := range chain {
			fmt.Printf("[%d|%d] ", d.A, d.B)
		}
		fmt.Println()
	} else {
		fmt.Println("\nNão foi possível formar uma cadeia válida.")
	}
}
