package main

import (
	"fmt"
)

func main() {
	var numeros [5]int
	var soma int

	fmt.Println("Digite 5 números inteiros:")

	for i := 0; i < len(numeros); i++ {
		fmt.Printf("Número %d: ", i+1)
		fmt.Scan(&numeros[i])
		soma += numeros[i] // já soma conforme vai lendo
	}

	media := float64(soma) / float64(len(numeros)) // conversão para float para ter precisão decimal

	fmt.Println("\nNúmeros digitados:")
	for i, v := range numeros {
		fmt.Printf("Posição %d: %d\n", i, v)
	}

	fmt.Printf("\nMédia dos números: %.2f\n", media)
}