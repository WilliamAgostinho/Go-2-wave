package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

func main() {
	var taxaCambioDolar float64 = 5.71
	var taxaCambioEuro float64 = 6.48
	var taxaCambioLibra float64 = 7.70

	var dinheiroAtual float64
	var tipoCambio int
	var dinheiroConvertido float64
	var moedaDestino string

	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Informe o valor que possui atualmente (em reais): ")
	valorStr, _ := reader.ReadString('\n')
	valorStr = strings.TrimSpace(valorStr)
	dinheiroAtual, _ = strconv.ParseFloat(valorStr, 64)

	for {
		fmt.Println("\nPara qual moeda deseja converter?")
		fmt.Println("1 - Dólar (USD)")
		fmt.Println("2 - Euro (EUR)")
		fmt.Println("3 - Libra (GBP)")
		fmt.Print("Escolha uma opção (1, 2 ou 3): ")

		opcaoStr, _ := reader.ReadString('\n')
		opcaoStr = strings.TrimSpace(opcaoStr)
		tipoCambio, _ = strconv.Atoi(opcaoStr)

		if tipoCambio == 1 || tipoCambio == 2 || tipoCambio == 3 {
			break
		} else {
			fmt.Println("Opção inválida! Tente novamente.")
		}
	}

	switch tipoCambio {
	case 1:
		dinheiroConvertido = dinheiroAtual / taxaCambioDolar
		moedaDestino = "USD"
	case 2:
		dinheiroConvertido = dinheiroAtual / taxaCambioEuro
		moedaDestino = "EUR"
	case 3:
		dinheiroConvertido = dinheiroAtual / taxaCambioLibra
		moedaDestino = "GBP"
	}

	fmt.Printf("\nValor convertido: %.2f %s\n", dinheiroConvertido, moedaDestino)
}
